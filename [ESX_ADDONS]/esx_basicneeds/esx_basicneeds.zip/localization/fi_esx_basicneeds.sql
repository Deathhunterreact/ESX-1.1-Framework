USE `essentialmode`;

INSERT INTO `items` (`name`, `label`, `limit`) VALUES
	('bread', 'Leipä', 10),
	('water', 'Vesi', 5)
;