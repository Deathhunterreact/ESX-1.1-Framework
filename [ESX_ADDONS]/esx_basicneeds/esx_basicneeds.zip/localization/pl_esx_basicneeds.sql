USE `essentialmode`;

INSERT INTO `items` (`name`, `label`, `limit`) VALUES
	('bread', 'Chleb', 10),
	('water', 'Woda', 5)
;