Config = {}

Config.StatusMax      = 1000000
Config.TickTime       = 2000
Config.UpdateInterval = 10000